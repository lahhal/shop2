app_name = 'pizzas'

urlpatterns = [

]